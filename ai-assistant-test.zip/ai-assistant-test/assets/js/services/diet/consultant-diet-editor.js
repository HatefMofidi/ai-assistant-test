class ConsultantDietEditor {
    constructor(containerId = 'consultation-editor') {
        this.container = document.getElementById(containerId);
        this.currentRequestId = null;
        this.originalData = null;
        this.isEditing = false;
        this.currentEditElement = null;
        this.currentData = null; // داده‌های جاری
        
        if (!this.container) {
            console.error(`Container with ID '${containerId}' not found`);
            return;
        }
    }

    init(data, requestId) {
        this.originalData = data;
        this.currentRequestId = requestId;
        // استخراج داده‌های رژیم
        const { original_data, consultation_data } = data;
        const dietData = consultation_data?.final_diet_data || original_data?.ai_response;
        
        try {
            this.currentData = typeof dietData === 'string' ? JSON.parse(dietData) : dietData;
        } catch (e) {
            console.error('Error parsing diet data:', e);
            this.currentData = null;
        }        
        this.render();
    }

    render() {
        if (!this.originalData || !this.currentData) {
            this.container.innerHTML = '<div class="consultant-loading">داده‌ها برای نمایش موجود نیست</div>';
            return;
        }


        this.container.innerHTML = this.renderStructuredEditor(this.currentData);
        this.setupEditEvents();
    }

    renderStructuredEditor(data) {
        return `
            <div class="consultant-editor-tabs">
                <div class="consultant-editor-tab active" data-tab="preview">
                    <i class="fas fa-eye"></i> پیش‌نمایش
                </div>
                <div class="consultant-editor-tab" data-tab="json">
                    <i class="fas fa-code"></i> ویرایش JSON
                </div>
            </div>

            <div class="consultant-editor-content">
                <div class="consultant-editor-pane active" id="preview-pane">
                    <div class="consultant-editor-actions">
                        <button class="consultant-btn consultant-btn-primary" id="expand-all-btn">
                            <i class="fas fa-expand"></i> باز کردن همه بخش‌ها
                        </button>
                        <button class="consultant-btn consultant-btn-secondary" id="collapse-all-btn">
                            <i class="fas fa-compress"></i> بستن همه بخش‌ها
                        </button>
                    </div>
                    <div class="consultant-diet-preview" id="consultant-diet-preview">
                        ${this.renderDietPlan(data)}
                    </div>
                </div>

                <div class="consultant-editor-pane" id="json-pane">
                    <div class="consultant-json-editor">
                        <h4><i class="fas fa-edit"></i> ویرایش مستقیم JSON</h4>
                        <textarea id="diet-json-editor" style="width: 100%; height: 400px; font-family: monospace;">${JSON.stringify(this.currentData, null, 2)}</textarea>
                        <div class="consultant-json-actions">
                            <button class="consultant-btn consultant-btn-primary" id="update-from-json-btn">
                                <i class="fas fa-sync"></i> بروزرسانی پیش‌نمایش از JSON
                            </button>
                            <button class="consultant-btn consultant-btn-secondary" id="reset-json-btn">
                                <i class="fas fa-undo"></i> بازنشانی به حالت اولیه
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="consultant-notes-section">
                <label for="consultant-notes">
                    <i class="fas fa-sticky-note"></i> یادداشت‌های مشاور:
                </label>
                <textarea id="consultant-notes" style="" placeholder="یادداشت‌ها و توضیحات خود را اینجا بنویسید...">${this.escapeHtml(this.originalData.consultation_data?.consultant_notes || '')}</textarea>
            </div>
        `;
    }

    renderSimpleTextEditor(text) {
        return `
            <div class="consultant-simple-editor">
                <h4><i class="fas fa-edit"></i> ویرایش متن رژیم</h4>
                <textarea id="diet-text-editor" style="width: 100%; height: 400px; font-family: monospace;">${this.escapeHtml(text)}</textarea>
                
                <div class="consultant-notes-section">
                    <label for="consultant-notes">
                        <i class="fas fa-sticky-note"></i> یادداشت‌های مشاور:
                    </label>
                    <textarea id="consultant-notes" style="width: 100%; height: 100px;" placeholder="یادداشت‌ها و توضیحات خود را اینجا بنویسید...">${this.escapeHtml(this.originalData.consultation_data?.consultant_notes || '')}</textarea>
                </div>
            </div>
        `;
    }

    renderDietPlan(data) {
        if (!data.sections || !Array.isArray(data.sections)) {
            return `<div class="consultant-debug-info">
                <h3>داده‌های خام:</h3>
                <pre>${JSON.stringify(data, null, 2)}</pre>
            </div>`;
        }

        let html = '<div class="consultant-diet-plan">';
        
        data.sections.forEach((section, sectionIndex) => {
            html += this.renderSection(section, sectionIndex);
        });

        if (data.footer) {
            html += `<div class="consultant-footer">${this.escapeHtml(data.footer)}</div>`;
        }

        html += '</div>';
        return html;
    }

    renderSection(section, sectionIndex) {
        return `
            <div class="consultant-section" data-section-index="${sectionIndex}">
                <div class="consultant-section-header">
                    <h2>
                        <i class="fas fa-${this.getSectionIcon(section.title)}"></i>
                        <span class="editable-text" data-path="sections.${sectionIndex}.title">${this.escapeHtml(section.title || 'بخش بدون عنوان')}</span>
                    </h2>
                    <i class="fas fa-chevron-down consultant-accordion-icon"></i>
                </div>
                <div class="consultant-section-content">
                    ${this.renderSectionContent(section.content, sectionIndex)}
                </div>
            </div>
        `;
    }

    renderSectionContent(content, sectionIndex) {
        if (!content) return '<p>محتوایی موجود نیست</p>';
        
        let html = '';
        
        if (Array.isArray(content)) {
            content.forEach((sub, subIndex) => {
                html += this.renderSubContent(sub, sectionIndex, subIndex);
            });
        } else if (typeof content === 'object') {
            html += this.renderSubContent(content, sectionIndex, 0);
        } else {
            html += `<p class="editable-text" data-path="sections.${sectionIndex}.content">${this.escapeHtml(content)}</p>`;
        }
        
        return html;
    }

    renderSubContent(sub, sectionIndex, subIndex) {
        let html = '';
        
        if (sub.subtitle) {
            html += `<h3 class="editable-text" data-path="sections.${sectionIndex}.content.${subIndex}.subtitle">${this.escapeHtml(sub.subtitle)}</h3>`;
        }

        if (sub.type === 'list' && sub.items) {
            html += this.renderList(sub.items, sectionIndex, subIndex);
        } else if (sub.type === 'table' && sub.headers && sub.rows) {
            html += this.renderTable(sub, sectionIndex, subIndex);
        } else if (sub.type === 'paragraph' && sub.text) {
            html += `<p class="editable-text" data-path="sections.${sectionIndex}.content.${subIndex}.text">${this.escapeHtml(sub.text)}</p>`;
        } else if (sub.text) {
            html += `<p class="editable-text" data-path="sections.${sectionIndex}.content.${subIndex}.text">${this.escapeHtml(sub.text)}</p>`;
        }

        return html;
    }

    renderList(items, sectionIndex, subIndex) {
        let html = '<ul>';
        items.forEach((item, itemIndex) => {
            if (typeof item === 'string') {
                html += `<li class="editable-text" data-path="sections.${sectionIndex}.content.${subIndex}.items.${itemIndex}">${this.escapeHtml(item)}</li>`;
            } else if (item.label && item.value) {
                html += `
                    <li>
                        <span class="editable-text" data-path="sections.${sectionIndex}.content.${subIndex}.items.${itemIndex}.label">${this.escapeHtml(item.label)}</span>: 
                        <span class="editable-text" data-path="sections.${sectionIndex}.content.${subIndex}.items.${itemIndex}.value">${this.escapeHtml(item.value)}</span>
                    </li>
                `;
            }
        });
        html += '</ul>';
        return html;
    }

    renderTable(tableData, sectionIndex, subIndex) {
        // استفاده از کارت‌ها به جای جدول
        return this.renderTableAsCards(tableData, sectionIndex, subIndex);
    }
    
    renderTableAsCards(tableData, sectionIndex, subIndex) {
        if (!tableData.headers || !tableData.rows) {
            return '<div class="consultant-error">داده‌های جدول نامعتبر است</div>';
        }
    
        console.log('Rendering table as cards:', tableData);
    
        let html = '<div class="consultant-cards-container">';
        
        // ایجاد کارت برای هر ردیف
        tableData.rows.forEach((row, rowIndex) => {
            html += this.renderDayCard(row, tableData.headers, sectionIndex, subIndex, rowIndex);
        });
        
        html += '</div>';
        
        return html;
    }
    
    renderDayCard(row, headers, sectionIndex, subIndex, rowIndex) {
        const dayName = row[0] || `روز ${rowIndex + 1}`;
        
        let html = `
            <div class="consultant-day-card">
                <div class="consultant-day-header">
                    <i class="fas fa-calendar-day"></i>
                    <span class="editable-text" data-path="sections.${sectionIndex}.content.${subIndex}.rows.${rowIndex}.0">${this.escapeHtml(dayName)}</span>
                </div>
                <div class="consultant-meals-container">
        `;
        
        // ایجاد بخش‌های غذایی برای هر ستون (به جز ستون اول که نام روز است)
        for (let i = 1; i < headers.length; i++) {
            if (row[i] && row[i].trim() !== '') {
                const mealName = headers[i] || `وعده ${i}`;
                html += this.renderMealSection(row[i], mealName, sectionIndex, subIndex, rowIndex, i);
            }
        }
        
        html += `
                </div>
            </div>
        `;
        
        return html;
    }
    
    renderMealSection(mealContent, mealName, sectionIndex, subIndex, rowIndex, columnIndex) {
        const mealIcon = this.getMealIcon(columnIndex, mealName);
        
        return `
            <div class="consultant-meal-section">
                <div class="consultant-meal-title">
                    <i class="fas fa-${mealIcon}"></i>
                    <span class="editable-text" data-path="sections.${sectionIndex}.content.${subIndex}.headers.${columnIndex}">${this.escapeHtml(mealName)}</span>
                </div>
                <div class="consultant-meal-content editable-text" data-path="sections.${sectionIndex}.content.${subIndex}.rows.${rowIndex}.${columnIndex}">
                    ${this.escapeHtml(mealContent)}
                </div>
            </div>
        `;
    }
    
    getMealIcon(columnIndex, mealName) {
        const mealIcons = {
            'صبحانه': 'sun',
            'ناهار': 'sun', 
            'شام': 'moon',
            'میان‌وعده': 'apple-alt',
            'میان وعده': 'apple-alt',
            'میان‌وعده صبح': 'sun',
            'میان‌وعده عصر': 'apple-alt',
            'عصرانه': 'apple-alt'
        };
        
        // جستجو بر اساس نام وعده
        const lowerMealName = mealName.toLowerCase();
        for (const [key, icon] of Object.entries(mealIcons)) {
            if (lowerMealName.includes(key.toLowerCase())) {
                return icon;
            }
        }
        
        // اگر پیدا نشد، بر اساس index
        const defaultIcons = ['sun', 'sun', 'moon', 'apple-alt', 'utensils'];
        return defaultIcons[columnIndex - 1] || 'utensils';
    }

    setupEditEvents() {
        // تب‌ها
        this.setupTabs();
        
        // آکاردئون‌ها
        this.setupAccordions();
        
        // دکمه‌های اکشن
        this.setupActionButtons();
        
        // ویرایش دبل کلیک
        this.setupDoubleClickEdit();
    }

    setupTabs() {
        const tabs = this.container.querySelectorAll('.consultant-editor-tab');
        const panes = this.container.querySelectorAll('.consultant-editor-pane');

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                tabs.forEach(t => t.classList.remove('active'));
                panes.forEach(p => p.classList.remove('active'));

                tab.classList.add('active');
                const tabId = tab.getAttribute('data-tab');
                const pane = document.getElementById(`${tabId}-pane`);
                if (pane) {
                    pane.classList.add('active');
                }
            });
        });
    }

    setupAccordions() {
        const headers = this.container.querySelectorAll('.consultant-section-header');
        
        headers.forEach(header => {
            header.addEventListener('click', function() {
                const isActive = this.classList.contains('active');
                const content = this.nextElementSibling;
                
                if (isActive) {
                    this.classList.remove('active');
                    content.style.maxHeight = '0';
                } else {
                    this.classList.add('active');
                    content.style.maxHeight = content.scrollHeight + 'px';
                }
            });
        });

        // باز کردن اولین بخش
        if (headers[0]) {
            headers[0].classList.add('active');
            const firstContent = headers[0].nextElementSibling;
            firstContent.style.maxHeight = firstContent.scrollHeight + 'px';
        }
    }

    setupActionButtons() {
        // باز کردن همه بخش‌ها
        const expandBtn = document.getElementById('expand-all-btn');
        if (expandBtn) {
            expandBtn.addEventListener('click', () => {
                const contents = this.container.querySelectorAll('.consultant-section-content');
                const headers = this.container.querySelectorAll('.consultant-section-header');
                
                headers.forEach(header => header.classList.add('active'));
                contents.forEach(content => {
                    content.style.maxHeight = content.scrollHeight + 'px';
                });
            });
        }

        // بستن همه بخش‌ها
        const collapseBtn = document.getElementById('collapse-all-btn');
        if (collapseBtn) {
            collapseBtn.addEventListener('click', () => {
                const contents = this.container.querySelectorAll('.consultant-section-content');
                const headers = this.container.querySelectorAll('.consultant-section-header');
                
                headers.forEach(header => header.classList.remove('active'));
                contents.forEach(content => {
                    content.style.maxHeight = '0';
                });
            });
        }

        // بروزرسانی از JSON
        const updateJsonBtn = document.getElementById('update-from-json-btn');
        if (updateJsonBtn) {
            updateJsonBtn.addEventListener('click', () => {
                const jsonEditor = document.getElementById('diet-json-editor');
                if (jsonEditor) {
                    try {
                        const newData = JSON.parse(jsonEditor.value);
                        this.updatePreviewFromJSON(newData);
                    } catch (e) {
                        alert('خطا در پارس کردن JSON: ' + e.message);
                    }
                }
            });
        }
    }

    setupDoubleClickEdit() {
        const editableElements = this.container.querySelectorAll('.editable-text');
        
        editableElements.forEach(element => {
            element.addEventListener('dblclick', (e) => {
                e.stopPropagation();
                this.startEditing(element);
            });
        });

        // کلیک خارج از حالت ویرایش - با استفاده از event delegation
        this.container.addEventListener('click', (e) => {
            if (this.isEditing && !e.target.matches('.consultant-edit-input')) {
                this.finishEditing();
            }
        });

        // کلید Escape - روی document
        document.addEventListener('keydown', (e) => {
            if (this.isEditing && e.key === 'Escape') {
                this.cancelEditing();
            }
        });
    }

startEditing(element) {
    if (this.isEditing) return;
    
    this.isEditing = true;
    this.currentEditElement = element;
    this.originalText = element.textContent;
    this.currentPath = element.dataset.path;
    
    // محاسبه موقعیت و اندازه دقیق المنت
    const rect = element.getBoundingClientRect();
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
    
    // تشخیص نوع المنت برای انتخاب input یا textarea
    const tagName = element.tagName.toLowerCase();
    const textLength = element.textContent.length;
    const isTableCell = element.closest('td, th');
    const isHeader = tagName === 'h1' || tagName === 'h2' || tagName === 'h3';
    
    let input;
    
    // برای تیترها، سلول‌های جدول و متن‌های کوتاه از input استفاده کن
    if (isHeader || isTableCell || textLength < 100) {
        input = document.createElement('input');
        input.type = 'text';
    } else {
        // برای متن‌های طولانی از textarea استفاده کن
        input = document.createElement('textarea');
        input.style.resize = 'vertical';
        input.style.minHeight = Math.max(rect.height, 60) + 'px';
    }
    
    input.value = this.originalText;
    input.className = 'consultant-edit-input';
    input.style.position = 'absolute';
    input.style.left = (rect.left + scrollLeft) + 'px';
    input.style.top = (rect.top + scrollTop) + 'px';
    input.style.width = rect.width + 'px';
    
    // برای input ارتفاع ثابت، برای textarea ارتفاع پویا
    if (input.nodeName === 'INPUT') {
        input.style.height = rect.height + 'px';
    } else {
        input.style.height = Math.max(rect.height, 80) + 'px';
    }
    
    input.style.zIndex = '10000';
    input.style.fontFamily = getComputedStyle(element).fontFamily;
    input.style.fontSize = getComputedStyle(element).fontSize;
    input.style.lineHeight = getComputedStyle(element).lineHeight;
    input.style.padding = getComputedStyle(element).padding;
    input.style.margin = getComputedStyle(element).margin;
    input.style.border = '2px solid #4e54c8';
    input.style.borderRadius = '4px';
    input.style.boxShadow = '0 4px 12px rgba(78, 84, 200, 0.3)';
    input.style.background = '#fff';
    input.style.outline = 'none';
    input.style.boxSizing = 'border-box';
    
    // مخفی کردن المنت اصلی
    element.style.visibility = 'hidden';
    
    document.body.appendChild(input);
    this.currentInput = input;
    
    // فوکوس و انتخاب متن
    input.focus();
    input.select();
    
    // مدیریت events
    const handleKeydown = (e) => {
        if (e.key === 'Enter' && e.ctrlKey) {
            finishEdit(); // Ctrl+Enter برای ذخیره
        } else if (e.key === 'Enter' && input.nodeName === 'TEXTAREA') {
            // در textarea اجازه Enter بده
            return;
        } else if (e.key === 'Enter') {
            finishEdit();
        } else if (e.key === 'Escape') {
            cancelEdit();
        }
    };
    
    const handleBlur = () => {
        finishEdit();
    };
    
    const handleResize = () => {
        // اگر پنجره تغییر اندازه داد، موقعیت input را آپدیت کن
        if (this.currentEditElement && input.parentNode) {
            const newRect = this.currentEditElement.getBoundingClientRect();
            const newScrollTop = window.pageYOffset || document.documentElement.scrollTop;
            const newScrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
            
            input.style.left = (newRect.left + newScrollLeft) + 'px';
            input.style.top = (newRect.top + newScrollTop) + 'px';
        }
    };
    
    const finishEdit = () => {
        const newValue = input.value.trim();
        
        // بازگرداندن المنت اصلی
        if (this.currentEditElement && this.currentEditElement.parentNode) {
            this.currentEditElement.style.visibility = 'visible';
            this.currentEditElement.textContent = newValue;
        }
        
        // حذف input
        if (input.parentNode) {
            input.remove();
        }
        
        // حذف event listeners
        window.removeEventListener('resize', handleResize);
        input.removeEventListener('keydown', handleKeydown);
        input.removeEventListener('blur', handleBlur);
        
        // آپدیت داده‌ها
        if (newValue !== this.originalText) {
            this.updateData(this.currentPath, newValue);
        }
        
        // پاک کردن
        this.isEditing = false;
        this.currentEditElement = null;
        this.currentInput = null;
    };
    
    const cancelEdit = () => {
        // بازگرداندن مقدار اصلی
        if (this.currentEditElement && this.currentEditElement.parentNode) {
            this.currentEditElement.style.visibility = 'visible';
        }
        
        // حذف input
        if (input.parentNode) {
            input.remove();
        }
        
        // حذف event listeners
        window.removeEventListener('resize', handleResize);
        input.removeEventListener('keydown', handleKeydown);
        input.removeEventListener('blur', handleBlur);
        
        // پاک کردن
        this.isEditing = false;
        this.currentEditElement = null;
        this.currentInput = null;
    };
    
    input.addEventListener('keydown', handleKeydown);
    input.addEventListener('blur', handleBlur);
    window.addEventListener('resize', handleResize);
    
    // برای textarea، ارتفاع را بر اساس محتوا تنظیم کن
    if (input.nodeName === 'TEXTAREA') {
        setTimeout(() => {
            input.style.height = 'auto';
            input.style.height = Math.max(input.scrollHeight, 80) + 'px';
        }, 0);
        
        // هنگام تایپ، ارتفاع را تنظیم کن
        input.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.max(this.scrollHeight, 80) + 'px';
        });
    }
}
    saveEdit(input) {
        // حذف event listeners برای جلوگیری از اجرای تکراری
        input.removeEventListener('keydown', this.handleInputKeydown);
        input.removeEventListener('blur', this.handleInputBlur);
        
        const newValue = input.value.trim();
        const path = input.dataset.path;
        const originalElement = this.currentEditElement;
        
        if (originalElement && originalElement.parentNode) {
            // بازگرداندن المنت اصلی
            originalElement.textContent = newValue;
            originalElement.style.display = '';
            
            // حذف input
            if (input.parentNode) {
                input.remove();
            }
            
            // آپدیت داده‌ها
            this.updateData(path, newValue);
        }
        
        this.isEditing = false;
        this.currentEditElement = null;
        this.handleInputKeydown = null;
        this.handleInputBlur = null;
    }

    cancelEditing() {
        if (!this.isEditing || !this.currentEditElement) return;
        
        const input = this.container.querySelector('.consultant-edit-input');
        if (input && this.currentEditElement && this.currentEditElement.parentNode) {
            // حذف event listeners
            input.removeEventListener('keydown', this.handleInputKeydown);
            input.removeEventListener('blur', this.handleInputBlur);
            
            // بازگرداندن المنت اصلی
            this.currentEditElement.style.display = '';
            
            // حذف input
            if (input.parentNode) {
                input.remove();
            }
        }
        
        this.isEditing = false;
        this.currentEditElement = null;
        this.handleInputKeydown = null;
        this.handleInputBlur = null;
    }

    finishEditing() {
        if (!this.isEditing) return;
        
        const input = this.container.querySelector('.consultant-edit-input');
        if (input) {
            this.saveEdit(input);
        } else {
            this.cancelEditing();
        }
    }

    // متد کمکی برای پیدا کردن المنت اصلی
    findOriginalElement(input) {
        const path = input.dataset.path;
        return this.container.querySelector(`[data-path="${path}"]`);
    }
    
    
    updateData(path, value) {
        console.log('Updating data path:', path, 'to:', value);
        
        // آپدیت داده‌ها بر اساس مسیر
        this.updateNestedData(this.currentData, path, value);
        
        // آپدیت JSON editor
        this.updateJsonEditor();
        
        // آپدیت پیش‌نمایش
        this.updatePreview();
    }

    updateNestedData(obj, path, value) {
        const keys = path.split('.');
        let current = obj;
        
        for (let i = 0; i < keys.length - 1; i++) {
            const key = keys[i];
            // اگر کلید عددی است، به آرایه تبدیل کن
            if (!isNaN(keys[i + 1])) {
                if (!current[key] || !Array.isArray(current[key])) {
                    current[key] = [];
                }
            } else {
                if (!current[key] || typeof current[key] !== 'object') {
                    current[key] = {};
                }
            }
            current = current[key];
        }
        
        const lastKey = keys[keys.length - 1];
        
        // اگر مقدار عددی است، به عدد تبدیل کن
        if (!isNaN(value) && value.trim() !== '') {
            current[lastKey] = Number(value);
        } else {
            current[lastKey] = value;
        }
    }

    updateJsonEditor() {
        const jsonEditor = document.getElementById('diet-json-editor');
        if (jsonEditor) {
            jsonEditor.value = JSON.stringify(this.currentData, null, 2);
        }
    }

    updatePreview() {
        const previewContainer = document.getElementById('consultant-diet-preview');
        if (previewContainer) {
            previewContainer.innerHTML = this.renderDietPlan(this.currentData);
            this.setupDoubleClickEdit();
            this.setupAccordions();
        }
    }

    setupActionButtons() {
        // باز کردن همه بخش‌ها
        const expandBtn = document.getElementById('expand-all-btn');
        if (expandBtn) {
            expandBtn.addEventListener('click', () => {
                this.expandAllSections();
            });
        }

        // بستن همه بخش‌ها
        const collapseBtn = document.getElementById('collapse-all-btn');
        if (collapseBtn) {
            collapseBtn.addEventListener('click', () => {
                this.collapseAllSections();
            });
        }

        // بروزرسانی از JSON
        const updateJsonBtn = document.getElementById('update-from-json-btn');
        if (updateJsonBtn) {
            updateJsonBtn.addEventListener('click', () => {
                this.updateFromJson();
            });
        }

        // بازنشانی JSON
        const resetJsonBtn = document.getElementById('reset-json-btn');
        if (resetJsonBtn) {
            resetJsonBtn.addEventListener('click', () => {
                this.resetJson();
            });
        }
    }

    expandAllSections() {
        const contents = this.container.querySelectorAll('.consultant-section-content');
        const headers = this.container.querySelectorAll('.consultant-section-header');
        
        headers.forEach(header => header.classList.add('active'));
        contents.forEach(content => {
            content.style.maxHeight = content.scrollHeight + 'px';
        });
    }

    collapseAllSections() {
        const contents = this.container.querySelectorAll('.consultant-section-content');
        const headers = this.container.querySelectorAll('.consultant-section-header');
        
        headers.forEach(header => header.classList.remove('active'));
        contents.forEach(content => {
            content.style.maxHeight = '0';
        });
    }

    updateFromJson() {
        const jsonEditor = document.getElementById('diet-json-editor');
        if (jsonEditor) {
            try {
                const newData = JSON.parse(jsonEditor.value);
                this.currentData = newData;
                this.updatePreview();
                this.showMessage('پیش‌نمایش با موفقیت بروزرسانی شد', 'success');
            } catch (e) {
                this.showMessage('خطا در پارس کردن JSON: ' + e.message, 'error');
            }
        }
    }

    resetJson() {
        const { original_data, consultation_data } = this.originalData;
        const dietData = consultation_data?.final_diet_data || original_data?.ai_response;
        
        try {
            this.currentData = typeof dietData === 'string' ? JSON.parse(dietData) : dietData;
            this.updateJsonEditor();
            this.updatePreview();
            this.showMessage('JSON به حالت اولیه بازنشانی شد', 'success');
        } catch (e) {
            this.showMessage('خطا در بازنشانی داده‌ها', 'error');
        }
    }

    showMessage(message, type) {
        // حذف پیام قبلی
        const existingMessage = this.container.querySelector('.consultant-editor-message');
        if (existingMessage) {
            existingMessage.remove();
        }

        const messageDiv = document.createElement('div');
        messageDiv.className = `consultant-editor-message ${type}`;
        messageDiv.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check' : 'exclamation-triangle'}"></i>
            ${message}
        `;

        this.container.insertBefore(messageDiv, this.container.firstChild);

        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 3000);
    }

    getEditedData() {
        return this.currentData;
    }

    getFinalDietData() {
        return JSON.stringify(this.currentData, null, 2);
    }

    updatePreviewFromJSON(newData) {
        const previewContainer = document.getElementById('consultant-diet-preview');
        if (previewContainer) {
            previewContainer.innerHTML = this.renderDietPlan(newData);
            this.setupDoubleClickEdit();
            this.setupAccordions();
        }
    }

    getEditedData() {
        // این متد داده‌های ویرایش شده را برمی‌گرداند
        const jsonEditor = document.getElementById('diet-json-editor');
        if (jsonEditor) {
            try {
                return JSON.parse(jsonEditor.value);
            } catch (e) {
                console.error('Error parsing edited JSON:', e);
            }
        }
        
        return this.originalData;
    }

    getSectionIcon(sectionTitle) {
        const icons = {
            'اطلاعات کاربر': 'user',
            'اطلاعات تغذیه‌ای': 'chart-pie',
            'برنامه هفتگی': 'calendar-alt',
            'توصیه‌های تکمیلی': 'lightbulb',
            'نتایج برنامه غذایی': 'utensils'
        };
        
        return icons[sectionTitle] || 'file-alt';
    }

    escapeHtml(unsafe) {
        if (!unsafe) return '';
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
    
    
    // اضافه کردن این متد به کلاس
    getInputTypeForElement(element) {
        const tagName = element.tagName.toLowerCase();
        const textLength = element.textContent.length;
        const isHeader = tagName === 'h1' || tagName === 'h2' || tagName === 'h3';
        const isTableCell = element.closest('td, th');
        const isList = element.closest('li');
        
        // برای تیترها و سلول‌های جدول از input استفاده کن
        if (isHeader || isTableCell || textLength < 100) {
            return 'input';
        }
        
        // برای متن‌های طولانی از textarea استفاده کن
        return 'textarea';
    }    
}