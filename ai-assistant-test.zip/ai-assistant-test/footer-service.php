<!--/home/aidastya/public_html/wp-content/themes/ai-assistant/footer-service.php-->
<?php wp_footer(); ?>
</body>
</html>
